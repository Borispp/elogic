<?php
/**
 * Template Name: MainPage
 */

get_header(); ?>
<div class="wide_slider">
	<ul id="top_slider">
		<?php
			if( have_rows('slides') ):
				while( have_rows('slides') ): the_row();
					echo '
					<li style="background: url(\''.get_sub_field('background').'\')">
						<img src="'.get_sub_field('slider_image').'" alt="" class="slider_image" style="'.get_sub_field('slider_image_css').'">
						<div class="bg_over">
							<div class="inner-slide">
								<div class="inner--slide_align">
									<h2>'.get_sub_field('headline').'</h2>
									<p>'.get_sub_field('description').'</p>
								</div>
							</div>
						</div>
					</li>
					';
				endwhile;
			endif;
		?>
	</ul>
</div>

<?php
	if( have_rows('bricks') ):
		while( have_rows('bricks') ): the_row();
			echo '
			<div class="bricks">
				<div class="bricks--block">
					<h2>'.get_sub_field('headline').'</h2>
					<a href="'.get_sub_field('link_url').'" class="btn m-wide">'.get_sub_field('link_text').'</a>
				</div>
			</div>
			';
		endwhile;
	endif;
?>


<?php
	if( have_rows('marketing_to_match_block') ):
		while( have_rows('marketing_to_match_block') ): the_row();

			echo
				'<div class="marketing promo_block">
					<div class="inner_block">
						<h2 class="promo_block--headline">'.get_sub_field('headline').'</h2>
						<p class="promo_block--description">'.get_sub_field('description').'</p>';
						echo '<ul class="promo_block--offers m-two_offers">';
						while( have_rows('promo_icons') ): the_row();
							$i++;
							echo '<li class="'.get_sub_field('class_for_icons').'">
								<h3>'.get_sub_field('headline').'</h3>
								<p>'.get_sub_field('description').'</p>
							</li>';
						endwhile;
						echo '</ul>';

			echo '
				</div>
					</div>';
		endwhile;
	endif;
?>


<?php
	if( have_rows('revolutionary_marketing') ):
		while( have_rows('revolutionary_marketing') ): the_row();
			echo
				'<div class="marketing--info">
					<div class="inner_block">
						<h2 class="promo_block--headline">'.get_sub_field('headline').'</h2>
						<p class="promo_block--description">'.get_sub_field('description').'</p>';
						echo '<ul class="features_list">';
						while( have_rows('promo_icons') ): the_row();
							$i++;
							echo '<li class="'.get_sub_field('class_for_icons').'">
								<span class="features--icon"></span>
								<h3>'.get_sub_field('headline').'</h3>
								<p>'.get_sub_field('description').'</p>
							</li>';
						endwhile;
						echo '</ul>';

			echo '
				</div>
					</div>';
		endwhile;
	endif;
?>

<?php
	if (get_field('headnex_featured')):
		echo '
		<div class="fybber_featured">
			<div class="inner_block">
				<h2>Headnex featured on</h2>
					<ul class="fybber_featured--list">';

				if( have_rows('featured') ):
					while( have_rows('featured') ): the_row();
						echo '<li><img src="'.get_sub_field('logo')['url'].'" width="'.(get_sub_field('logo')['width']/2).'"/></li>';
					endwhile;
				endif;

		echo '</ul></div></div>';
	endif;

?>

<?php
get_footer();
?>

<?php
/**
 * The template for displaying the footer
 */
?>
<?php
	global $childcats;
	global $childcats_history;
	global $childcats_order;
	global $childcats_contacts;
?>

<footer id="footer">
	<div class="inner_block">
		<div class="footer--logo">
			<a href="#"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/content/footer_logo.png" alt="" width="125"></a>
			<p>© 2015 Headnex.com <br> All the rights are reserved</p>
		</div>

		<div class="footer--fast_links">
			<h2>Fast links</h2>
			<?php
				$defaults = array(
				'theme_location'  => '',
				'menu'            => 'Footer Menu',
				'container'       => '',
				'container_class' => '',
				'container_id'    => '',
				'menu_class'      => 'menu',
				'menu_id'         => 'footer--menu',
				'echo'            => true,
				'fallback_cb'     => 'wp_page_menu',
				'before'          => '',
				'after'           => '',
				'link_before'     => '',
				'link_after'      => '',
				'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
				'depth'           => 0,
				'walker'          => ''
			);

			wp_nav_menu( $defaults );
		?>
		</div>

		<div class="footer--about">
			<?php
				dynamic_sidebar('Footer Widget Area')
			?>
<!--             <h2>Follow us</h2>
<ul class="footer--social">
<li><a href="#"><img src="./assets/images/content/fb.png" alt="" width="32"></a></li>
<li><a href="#"><img src="./assets/images/content/tw.png" alt="" width="32"></a></li>
<li><a href="#"><img src="./assets/images/content/gp.png" alt="" width="32"></a></li>
</ul> -->
		</div>
	</div>
</footer>
</div>


	<script src="<?php echo get_template_directory_uri(); ?>/assets/libs/jquery/dist/jquery.min.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/assets/libs/bxslider/jquery.bxslider.min.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/assets/libs/select2/dist/js/select2.min.js"></script>
	<script src="<?php echo get_template_directory_uri(); ?>/assets/scripts/main.js"></script>
	<script language="JavaScript">
		var slider = $('#top_slider').bxSlider({
			pager: true
		});
	</script>

<?php wp_footer(); ?>
</body>
</html>

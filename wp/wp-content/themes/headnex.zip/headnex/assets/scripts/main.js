(function() {
  return $('.fake-select').select2({
    minimumResultsForSearch: -1
  });
})();

<?php
/**
 * Template Name: InnerPage
 */

get_header(); ?>
<div class="single_image" style="background: url('<?php echo get_field('header_background_image') ?>'); height: 365px;">
		<h2><?php the_title(); ?></h2>
</div>

<div class="content m-bg_brown">
		<?php
			if (have_posts()) :
				while (have_posts()) :
					the_post();
						echo '<div class="faq--block">';
							the_content();
						echo '</div>';
				endwhile;
			endif;
		?>

		<?php
			if( have_rows('advertisers') ):
				echo '<div class="content m-bg_brown"><div class="inner--block"><ul class="description_list">';
				while( have_rows('advertisers') ): the_row();
					echo '
					<li>
						<div class="description_list--text">
							<h2>'.get_sub_field('headline').'</h2>
							<p>'.get_sub_field('description').'</p>
						</div>
						<img src="'.get_sub_field('image').'" alt="" width="'.get_sub_field('image_width').'">
					</li>
					';
				endwhile;
				echo '</ul></div></div>';
			endif;
		?>
		<?php
			if( get_field('about') ):
				echo '<div class="content m-bg_brown"><div class="about--block">';
				echo get_field('about');
				echo '</div></div>';
			endif;
		?>

		<?php
			if( have_rows('marketing_that_works') ):
				echo '<div class="bricks m-bg_white">';
				while( have_rows('marketing_that_works') ): the_row();
					echo '
					<div class="bricks--block">
						<h2 style="padding-top: 8px">'.get_sub_field('headline').'</h2>
						<a href="'.get_sub_field('button_link').'" class="btn m-wide" style="padding: 4px 24px 2px">'.get_sub_field('button_text').'</a>
					</div>
					';
				endwhile;
				echo '</div>';
			endif;
		?>
</div>


<?php
get_footer();
?>
